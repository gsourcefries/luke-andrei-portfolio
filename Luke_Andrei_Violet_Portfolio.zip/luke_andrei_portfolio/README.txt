LUKE ANDREI P. DELA CRUZ — VIOLET DIGITAL PORTFOLIO

PREVIEW LOCALLY
1. Extract the ZIP file.
2. Open the extracted folder.
3. Double-click index.html. It should open in your browser.
4. Keep the assets folder beside index.html. Do not move the files separately.

FILES
- index.html: responsive violet-themed portfolio
- assets/luke-andrei-profile.jpg: profile photo used in the hero section
- assets/Luke_Andrei_Dela_Cruz_Resume.pdf: downloadable resume

PUBLISH ONLINE WITH GITHUB PAGES (FREE)
1. Sign in to https://github.com/ or create an account.
2. Click the + button, then New repository.
3. Name it luke-andrei-portfolio.
4. Set it to Public, then create the repository.
5. Open the repository and choose Add file > Upload files.
6. Upload index.html and the entire assets folder (including both files inside).
7. Click Commit changes.
8. Open Settings > Pages.
9. Under Build and deployment, choose Deploy from a branch.
10. Select branch main and folder /(root), then Save.
11. Wait a few minutes and refresh the Pages section. GitHub will show your live website URL, usually:
    https://YOUR-USERNAME.github.io/luke-andrei-portfolio/

IMPORTANT
- Upload index.html at the repository root, not inside another folder.
- Keep the assets folder at the same level as index.html.
- Your resume contains personal contact information. Review it before publishing publicly.
- The website shows your email publicly; remove it if you prefer not to display it.
- No GitHub profile link was added because one was not provided.
